## Information

<div align="center">
<a href="https://github.com/BLUEHAT-PROTOCOL/hitori/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/BLUEHAT-PROTOCOL/hitori?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/BLUEHAT-PROTOCOL/hitori/network/members"><img title="Forks" src="https://img.shields.io/github/forks/BLUEHAT-PROTOCOL/hitori?label=Forks&color=blue&style=flat-square"></a>
<a href="https://github.com/BLUEHAT-PROTOCOL/hitori/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/BLUEHAT-PROTOCOL/hitori?label=Stars&color=yellow&style=flat-square"></a>
<a href="https://github.com/BLUEHAT-PROTOCOL/hitori/issues"><img title="Issues" src="https://img.shields.io/github/issues/BLUEHAT-PROTOCOL/hitori?label=Issues&color=success&style=flat-square"></a>
<a href="https://github.com/BLUEHAT-PROTOCOL/hitori/issues?q=is%3Aissue+is%3Aclosed"><img title="Issues" src="https://img.shields.io/github/issues-closed/BLUEHAT-PROTOCOL/hitori?label=Issues&color=red&style=flat-square"></a>
<a href="https://github.com/BLUEHAT-PROTOCOL/hitori/pulls"><img title="Pull Request" src="https://img.shields.io/github/issues-pr/BLUEHAT-PROTOCOL/hitori?label=PullRequest&color=success&style=flat-square"></a>
<a href="https://github.com/BLUEHAT-PROTOCOL/hitori/pulls?q=is%3Apr+is%3Aclosed"><img title="Pull Request" src="https://img.shields.io/github/issues-pr-closed/BLUEHAT-PROTOCOL/hitori?label=PullRequest&color=red&style=flat-square"></a>
</div>

This script is created by [BLUEHAT-PROTOCOL](https://github.com/BLUEHAT-PROTOCOL) using Node.js and the [WhiskeySocket/Baileys](https://github.com/WhiskeySockets/Baileys) library. The script is currently in the development phase (BETA), so there may still be some errors that can be ignored. If errors persist even after debugging, please contact the owner for assistance. ~ By Naze

## Contributor

- [BLUEHAT-PROTOCOL](https://github.com/BLUEHAT-PROTOCOL) (Pembuat)
- [BLUEHAT-PROTOCOL](https://github.com/BLUEHAT-PROTOCOL) (Penyedia Layanan API)
- [BLUEHAT-PROTOCOL](https://github.com/BLUEHAT-PROTOCOL) (Penyumbang Code)

#### Join Group
[![Grup WhatsApp](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/GfOHdOazk1r1A9ghAZSJmy?mode=ac_t) 

---
#### Deploy to Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/nazedev/hitori)

#### Heroku Buildpack
| Build Pack | LINK |
|--------|--------|
| **NODEJS** | heroku/nodejs |
| **FFMPEG** | [here](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **WEBP** | [here](https://github.com/clhuang/heroku-buildpack-webp-binaries.git) |
| **IMAGEMAGICK** | [here](https://github.com/DuckyTeam/heroku-buildpack-imagemagick) |

---
## For Windows/VPS/RDP User
* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/BLUEHAT-PROTOCOL/hitori
cd hitori
npm install
npm update
```
---
## For Termux/Ubuntu/SSH User
```bash
pkg update && pkg upgrade
pkg install git
pkg install nodejs
pkg install ffmpeg
pkg install imagemagick
git clone https://github.com/BLUEHAT-PROTOCOL/hitori
cd hitori
npm install
```

[ RECOMMENDED INSTALL ON TERMUX ]
```bash
pkg install yarn
yarn
```

---

## Run
```bash
node .
```
---

### Connection Options
- Support Qr Code
- Support Pairing Code
---

### Features
| Menu     | Bot | Group | Search | Download | Tools | Ai | Game | Fun | Owner |
| -------- | --- | ----- | ------ | -------- | ----- | -- | ---- | --- | ----- |
| Work     |  ✅  |   ✅   |    ✅    |     ✅     |   ✅   | ✅ |   ✅   |  ✅  |    ✅    |


License: [MIT](https://choosealicense.com/licenses/mit/)

#### Support Me
- [Saweria](https://saweria.co/BPROTOCOL)

## Thanks to

| [![BLUEHAT-PROTOCOL](https://github.com/BLUEHAT-PROTOCOL.png?size=100)](https://github.com/BLUEHAT-PROTOCOL) |
| --- | --- | --- | --- |
| [BLUEHAT-PROTOCOL](https://github.com/BLUEHAT-PROTOCOL) | 